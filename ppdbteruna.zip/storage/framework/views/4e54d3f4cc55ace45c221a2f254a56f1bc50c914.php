<?php $__env->startSection('title', 'PPDB - SMKS Teruna Padangsidimpuan'); ?>

<?php $__env->startSection('content'); ?>
    <div>
      <div class="mb-6 bg-white p-6 shadow rounded-md">
        <h3 class="text-xl">Aktivitas Portal PPDB</h3>
        <ul class="ml-4 mt-2 h-64 overflow-y-scroll">
           <?php $__currentLoopData = $registrasi['data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="text-gray-700 text text-<?php echo e($logger["{$value->status_registration}"][1]); ?>-700">
              * [<?php echo e(date("H:i", strtotime($value->updated_at))); ?>]
              <strong><i>#<a class="hover:underline" href="<?php echo e(url('/admin/detail/' . $value->id_registration )); ?>"><?php echo e($value->id_registration); ?></a></i></strong>
              <?php echo e($logger["{$value->status_registration}"][0]); ?>

              <?= ($value->status_registration == 'tervalidasi') ? $value['user']['username_user'] : '' ?>
            </li>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
      </div>
      <div class="mb-6 bg-white p-6 shadow rounded-md">
        <table class="table-auto w-full">
           <thead>
               <tr>
                   <th class="px-4 py-4 bg-gray-200 border-2">Jurusan</th>
                   <th class="px-4 py-4 bg-gray-200 border-2">Total Pendaftar*</th>
               </tr>
           </thead>
           <tbody>
            <?php if(isset($registrasi['jurusan'])): ?>
                <?php $__currentLoopData = $registrasi['jurusan']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="px-4 py-2 border-2"><?php echo e(config('custom.data.jurusan.' . $key) . ' (' . $key . ')'); ?></td>
                    <td class="px-4 py-2 border-2 text-center"><?php echo e($value->counter); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="px-4 py-2 border-2 text-right font-bold">Total Pendaftar</td>
                    <td class="px-4 py-2 border-2 text-center bg-gray-200"><?= isset($registrasi['semua']->counter) ? $registrasi['semua']->counter : '0' ?></td>
                </tr>
            <?php endif; ?>
           </tbody>
       </table>
       <small class="italic text-gray-700">* total berdasarkan akun yang terdaftar, bukan pendaftar yang telah tervalidasi</small>
      </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/ppdbteruna/resources/views/admin/home.blade.php ENDPATH**/ ?>