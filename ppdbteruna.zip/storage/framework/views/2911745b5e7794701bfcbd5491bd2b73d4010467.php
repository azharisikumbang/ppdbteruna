<!DOCTYPE html>
<html>
<head>
    <title>PPDB SMK Teruna Padangsidimpuan</title>
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('/css/tailwind.min.css')); ?>">
</head>
<body class="bg-green-300">
    <div class="container mx-auto">
        <?php echo $__env->yieldContent('content'); ?>
    </div>
</body>
</html>
<?php /**PATH /var/www/html/ppdbteruna/resources/views/templates/base.blade.php ENDPATH**/ ?>