<?php $__env->startSection('title', 'PPDB - SMKS Teruna Padangsidimpuan'); ?>

<?php $__env->startSection('content'); ?>
    <div class=" bg-white p-6 shadow rounded-md">
       <table class="table-auto w-full">
           <thead>
               <tr>
                   <th class="px-4 py-4 bg-gray-200 border-2 w-10">No</th>
                   <th class="px-4 py-4 bg-gray-200 border-2">No. Pendaftaran</th>
                   <th class="px-4 py-4 bg-gray-200 border-2">Nama</th>
                   <th class="px-4 py-4 bg-gray-200 border-2">No. Rekening</th>
                   <th class="px-4 py-4 bg-gray-200 border-2">Status</th>
               </tr>
           </thead>
           <tbody>
            <?php if(isset($registrasi)): ?>
                <?php
                    $no = 1;
                ?>
                <?php $__currentLoopData = $registrasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $regis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="px-4 py-2 border-2 text-center"><?php echo e((isset($_GET['page'])) ? (($_GET['page'] - 1) * 10) + $no++ : $no++); ?></td>
                    <td class="px-4 py-2 border-2">
                        <a class="hover:underline" href="<?php echo e(url('/admin/detail/' . $regis->id_registration)); ?>"><?php echo e($regis->id_registration); ?></a>
                    </td>
                    <td class="px-4 py-2 border-2"><?php echo e($regis['student']['name_student']); ?></td>
                    <td class="px-4 py-2 border-2">
                        <?php if(isset($regis['payment']['number_payment'])): ?>
                            <a class="hover:underline" href='<?php echo e(url("/files/pembayaran/{$regis["file"][0]["name_file"]}")); ?>' target="_blank"><?php echo e($regis['payment']['number_payment']); ?></a>
                        <?php else: ?>
                        -
                        <?php endif; ?>
                    </td>
                    <td class="px-4 py-2 border-2 text-center">
                        <?php if($validasi): ?>
                        <button onclick="validate(this)" data-status='tervalidasi' data-regid="<?php echo e($regis->id_registration); ?>" data-validator="<?php echo e($code_user); ?>" type="button" class="bg-orange-500 px-4 py-1 text-white rounded shadow">validasi</button>
                        <button onclick="validate(this)" data-status='gagal' data-regid="<?php echo e($regis->id_registration); ?>" data-validator="<?php echo e($code_user); ?>" type="button" class="bg-gray-500 px-4 py-1 text-white rounded shadow">batalkan</button>
                        <?php else: ?>
                            <button class="px-4 py-1 text-white rounded shadow bg-<?php echo e($html['color']["{$regis->status_registration}"]); ?>-500">
                                <?php echo e($regis->status_registration); ?>

                            </button>
                            <?php if($regis->status_registration == 'menunggu'): ?>
                                <button onclick="validate(this)" data-status='tervalidasi' data-regid="<?php echo e($regis->id_registration); ?>" title="Klik untuk memvalidasi" data-validator="<?php echo e($code_user); ?>" type="button" class="bg-orange-500 px-4 py-1 hover:bg-white hover:text-orange-500 text-white rounded shadow">validasi ?</button>
                            <?php endif; ?>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
           </tbody>
       </table>

       <div class="mt-4">
           <?php if($registrasi->hasPages()): ?>
            <div class="flex items-center">
                
                <?php if($registrasi->onFirstPage()): ?>
                    <span class="rounded-l rounded-sm border border-brand-light px-3 py-2 cursor-not-allowed no-underline">&laquo;</span>
                <?php else: ?>
                    <a
                        class="rounded-l rounded-sm border-t border-b border-l border-brand-light px-3 py-2 text-brand-dark hover:bg-brand-light no-underline"
                        href="<?php echo e($registrasi->previousPageUrl()); ?><?php echo e((isset($_GET['q'])) ? '&q=' . $_GET['q'] : ''); ?>"
                        rel="prev"
                    >
                        &laquo;
                    </a>
                <?php endif; ?>

                
                <?php if($registrasi->hasMorePages()): ?>
                    <a class="rounded-r rounded-sm border border-brand-light px-3 py-2 hover:bg-brand-light text-brand-dark no-underline" href="<?php echo e($registrasi->nextPageUrl()); ?><?php echo e((isset($_GET['q'])) ? '&q=' . $_GET['q'] : ''); ?>" rel="next">&raquo;</a>
                <?php else: ?>
                    <span class="rounded-r rounded-sm border border-brand-light px-3 py-2 hover:bg-brand-light text-brand-dark no-underline cursor-not-allowed">&raquo;</span>
                <?php endif; ?>

                <span class="ml-2">
                    Page <?php echo e($registrasi->currentPage()); ?> of <?php echo e(round($registrasi->total() / $registrasi->perPage())); ?>

                </span>
            </div>
        <?php endif; ?>
       </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/ppdbteruna/resources/views/admin/validasi.blade.php ENDPATH**/ ?>