<!DOCTYPE html>
<html>
<head>
    <title>PPDB SMK Teruna Padangsidimpuan</title>
    <link rel="stylesheet" type="text/css" href="{{ url('/css/tailwind.min.css') }}">
</head>
<body class="bg-green-300">
    <div class="container mx-auto">
        @yield('content')
    </div>
</body>
</html>
